const express = require("express");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const APP_NAME = process.env.APP_NAME || "Kubernetes Mini Lab API";
const API_VERSION = process.env.API_VERSION || "1.0.0";
const API_SECRET = process.env.API_SECRET || "not-configured";

let tasks = [
  {
    id: 1,
    title: "Create Kubernetes manifests",
    status: "todo"
  },
  {
    id: 2,
    title: "Test API deployment",
    status: "in-progress"
  }
];

app.get("/", (req, res) => {
  res.json({
    message: "Welcome to the Kubernetes Mini Lab Web API",
    appName: APP_NAME,
    version: API_VERSION
  });
});

app.get("/health", (req, res) => {
  res.json({
    status: "healthy",
    uptime: process.uptime()
  });
});

app.get("/config", (req, res) => {
  res.json({
    appName: APP_NAME,
    apiVersion: API_VERSION,
    secretConfigured: API_SECRET !== "not-configured"
  });
});

app.get("/tasks", (req, res) => {
  res.json(tasks);
});

app.post("/tasks", (req, res) => {
  const { title, status } = req.body;

  if (!title) {
    return res.status(400).json({
      error: "Task title is required"
    });
  }

  const newTask = {
    id: tasks.length + 1,
    title,
    status: status || "todo"
  };

  tasks.push(newTask);
  res.status(201).json(newTask);
});

app.put("/tasks/:id", (req, res) => {
  const taskId = parseInt(req.params.id);
  const { title, status } = req.body;

  const task = tasks.find((item) => item.id === taskId);

  if (!task) {
    return res.status(404).json({
      error: "Task not found"
    });
  }

  if (title) task.title = title;
  if (status) task.status = status;

  res.json(task);
});

app.delete("/tasks/:id", (req, res) => {
  const taskId = parseInt(req.params.id);
  const oldLength = tasks.length;

  tasks = tasks.filter((item) => item.id !== taskId);

  if (tasks.length === oldLength) {
    return res.status(404).json({
      error: "Task not found"
    });
  }

  res.json({
    message: "Task deleted successfully"
  });
});

app.listen(PORT, () => {
  console.log(`${APP_NAME} is running on port ${PORT}`);
});
